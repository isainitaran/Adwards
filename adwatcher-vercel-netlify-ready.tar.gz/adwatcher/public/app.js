const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
async function api(url,opt={}){const r=await fetch(url,{headers:{'Content-Type':'application/json',...(opt.headers||{})},...opt});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Request failed');return d}
async function loadMe(){return api('/api/me')}
function money(v){return `$${Number(v||0).toFixed(2)}`}
async function initNav(){const m=await loadMe();const els=$$('.user-name');els.forEach(e=>e.textContent=m.user?.display_name||'Guest');const login=$('.auth-action');if(login){login.textContent=m.user?'Account':'Sign in';login.href=m.user?'/account':'/account'}}
