# AdWatcher — full-stack rewards website starter

A responsive 3-page user website plus a separate admin panel.

## Included
- `/watch` — ad inventory, $0.01 default reward per valid view, balance and watch count.
- `/earn` — sponsored placements + earning/referral/payout instructions.
- `/account` — account dashboard, referral link, UPI/PayPal/crypto payout request and payment history.
- `/admin` — protected admin panel for ads, users, payout status and platform settings.
- SQLite persistence.
- Server-side salted `scrypt` password verification.
- Hashed IP uniqueness check (raw IP is not stored in the database).
- Referral qualification after 10 eligible ad watches and $1 referrer reward.
- $50 default payout minimum.
- Currency conversion settings for INR/EUR/GBP/AED/CAD/AUD.
- Ad impressions/clicks, user activity, balances, lifetime earnings and payout tracking.
- SEO metadata, canonical URLs, responsive UI, security headers and rate limiting.

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and set a strong `SESSION_SECRET` and `BASE_URL`.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000/watch`.
6. Admin: `http://localhost:3000/admin`.

### Bootstrap admin credentials
- Login ID: `Taran4906`
- Password: `Taran4906`

The supplied password is **not stored in the SQLite database**; the server seeds a salted `scrypt` hash. For a real deployment, rotate the bootstrap credential and use a dedicated secret-management system.

## Production requirements
This is a working starter, not a claim that third-party ad networks or payment providers are already integrated. Before accepting real money:

- Configure real Google OAuth and Apple Sign In credentials and callback handling.
- Use HTTPS/TLS and secure, rotated secrets.
- Replace in-memory sessions with a durable, encrypted session store or a properly designed auth service.
- Integrate PayPal/UPI/crypto providers through their official APIs; the current admin `paid` status is a bookkeeping control and does not itself transfer money.
- Add advertiser approval, fraud/anti-bot controls, age/identity and payout compliance as legally required.
- Review the one-account-per-IP rule carefully: shared Wi-Fi, carrier NAT and VPNs can cause false positives. The app stores a keyed hash rather than raw IPs.
- Add consented analytics and a privacy/retention policy before production tracking.
- Never accept arbitrary untrusted third-party JavaScript in ad embed code. The included sanitizer intentionally removes script tags and unsafe schemes.
