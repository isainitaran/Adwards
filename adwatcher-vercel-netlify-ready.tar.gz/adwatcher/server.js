const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const Database = require('better-sqlite3');
const sanitizeHtml = require('sanitize-html');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'data', 'app.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 provider TEXT NOT NULL,
 provider_id TEXT NOT NULL UNIQUE,
 display_name TEXT NOT NULL,
 email TEXT,
 ip_hash TEXT NOT NULL UNIQUE,
 referral_code TEXT NOT NULL UNIQUE,
 referred_by INTEGER,
 balance_usd REAL NOT NULL DEFAULT 0,
 lifetime_earned_usd REAL NOT NULL DEFAULT 0,
 ads_watched INTEGER NOT NULL DEFAULT 0,
 referral_qualified INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(referred_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS ads (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 url TEXT NOT NULL,
 embed_code TEXT,
 active INTEGER NOT NULL DEFAULT 1,
 reward_usd REAL NOT NULL DEFAULT 0.01,
 impressions INTEGER NOT NULL DEFAULT 0,
 clicks INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS watch_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 ad_id INTEGER NOT NULL,
 reward_usd REAL NOT NULL,
 watched_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(ad_id) REFERENCES ads(id)
);
CREATE TABLE IF NOT EXISTS payouts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 amount_usd REAL NOT NULL,
 method TEXT NOT NULL,
 destination TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 note TEXT,
 requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 processed_at TEXT,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admin_users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 login_id TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const ADMIN_ID = process.env.ADMIN_ID || 'Taran4906';
const BOOTSTRAP_ADMIN_HASH = '488c9ef3f5ebac2248e9c6e270c467cc:cad8af39fec1d49e88d63c8beddb9ced7feb1d9dbcc9086605526c3f3ebc28c6039cdb22ee590f5cfdd488c9749533b10953b1b0b8d24cce750e039aeae79fd7';
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, key] = stored.split(':');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(key, 'hex'), Buffer.from(derived, 'hex'));
}
if (!db.prepare('SELECT 1 FROM admin_users WHERE login_id=?').get(ADMIN_ID)) {
  db.prepare('INSERT INTO admin_users(login_id,password_hash) VALUES(?,?)').run(ADMIN_ID, BOOTSTRAP_ADMIN_HASH);
}

const defaults = {
  usd_inr: '92', usd_eur: '0.86', usd_gbp: '0.75', usd_aed: '3.67', usd_cad: '1.38', usd_aud: '1.52',
  payout_min_usd: '50', referral_reward_usd: '1', referral_ads_required: '10', reward_per_ad_usd: '0.01'
};
for (const [k,v] of Object.entries(defaults)) db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k,v);
if (!db.prepare('SELECT 1 FROM ads LIMIT 1').get()) {
  const ins = db.prepare('INSERT INTO ads(title,url,embed_code,reward_usd) VALUES(?,?,?,?)');
  ins.run('Welcome sponsor', 'https://example.com', '<div class="sponsor-card"><strong>Welcome sponsor</strong><span>Admin-managed ad placement</span></div>', 0.01);
  ins.run('Featured offer', 'https://example.com', '<div class="sponsor-card"><strong>Featured offer</strong><span>Replace this with your approved advertiser embed.</span></div>', 0.01);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(cookieParser(process.env.SESSION_SECRET || 'dev-only-change-me'));
app.use(rateLimit({windowMs: 15*60*1000, limit: 400, standardHeaders: true, legacyHeaders:false}));
app.use(express.static(path.join(__dirname,'public')));

const sessions = new Map();
const adminSessions = new Map();
function makeToken() { return crypto.randomBytes(32).toString('hex'); }
function hashIp(ip) { return crypto.createHash('sha256').update(`${process.env.SESSION_SECRET || 'dev'}:${ip}`).digest('hex'); }
function getUser(req) {
  const token = req.signedCookies.session;
  const id = token && sessions.get(token);
  if (!id) return null;
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (user) db.prepare('UPDATE users SET last_seen_at=CURRENT_TIMESTAMP WHERE id=?').run(id);
  return user || null;
}
function requireUser(req,res,next) { const u=getUser(req); if(!u) return res.status(401).json({error:'Sign in required'}); req.user=u; next(); }
function requireAdmin(req,res,next) { const token=req.signedCookies.admin_session; if(!token || !adminSessions.has(token)) return res.status(401).json({error:'Admin authentication required'}); next(); }
function setting(k) { return db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value; }
function sanitizeEmbed(html) {
  return sanitizeHtml(html || '', {allowedTags:['div','span','p','strong','b','em','a','img','iframe','video','br','h3','small'], allowedAttributes:{a:['href','target','rel'],img:['src','alt'],iframe:['src','width','height','allow','allowfullscreen','loading'],div:['class'],span:['class'],p:['class'],strong:['class'],small:['class'],h3:['class']}, allowedSchemes:['http','https']});
}

app.get('/api/settings', (req,res)=>res.json({currencies:{INR:Number(setting('usd_inr')),EUR:Number(setting('usd_eur')),GBP:Number(setting('usd_gbp')),AED:Number(setting('usd_aed')),CAD:Number(setting('usd_cad')),AUD:Number(setting('usd_aud'))}, payoutMin:Number(setting('payout_min_usd')), rewardPerAd:Number(setting('reward_per_ad_usd'))}));
app.get('/api/me', (req,res)=>{
  const u=getUser(req);
  if(!u) return res.json({user:null});
  const payout = db.prepare('SELECT * FROM payouts WHERE user_id=? ORDER BY id DESC').all(u.id);
  res.json({user:u, payouts:payout, referralLink:`${process.env.BASE_URL||`http://localhost:${PORT}`}/?ref=${u.referral_code}`});
});
app.get('/api/ads', requireUser, (req,res)=>{
  const ads=db.prepare('SELECT id,title,url,embed_code,reward_usd FROM ads WHERE active=1 ORDER BY id DESC').all();
  db.prepare('UPDATE ads SET impressions=impressions+1 WHERE active=1').run();
  res.json({ads:ads.map(a=>({...a, embed_code:sanitizeEmbed(a.embed_code)}))});
});
app.post('/api/auth/demo', (req,res)=>{
  const {name='Demo User', email='demo@example.com', provider='google', providerId} = req.body;
  const ipHash=hashIp(req.ip);
  let u=db.prepare('SELECT * FROM users WHERE provider_id=?').get(providerId || `${provider}:${email}`);
  if(!u) {
    const existingIp=db.prepare('SELECT id FROM users WHERE ip_hash=?').get(ipHash);
    if(existingIp) return res.status(409).json({error:'This device/IP is already associated with an account.'});
    const ref=crypto.randomBytes(5).toString('hex').toUpperCase();
    const referredByCode=req.body.referralCode;
    const parent=referredByCode ? db.prepare('SELECT id FROM users WHERE referral_code=?').get(referredByCode) : null;
    const info=db.prepare('INSERT INTO users(provider,provider_id,display_name,email,ip_hash,referral_code,referred_by) VALUES(?,?,?,?,?,?,?)').run(provider,providerId || `${provider}:${email}`,name,email,ipHash,ref,parent?.id||null);
    u=db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid);
  }
  const token=makeToken(); sessions.set(token,u.id); res.cookie('session',token,{signed:true,httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:7*24*3600*1000});
  res.json({ok:true,user:u});
});
app.post('/api/auth/logout',(req,res)=>{const t=req.signedCookies.session; if(t) sessions.delete(t); res.clearCookie('session'); res.json({ok:true});});
app.post('/api/ads/:id/watch', requireUser, (req,res)=>{
  const ad=db.prepare('SELECT * FROM ads WHERE id=? AND active=1').get(req.params.id);
  if(!ad) return res.status(404).json({error:'Ad not found'});
  const recent=db.prepare("SELECT 1 FROM watch_events WHERE user_id=? AND ad_id=? AND watched_at > datetime('now','-5 minutes')").get(req.user.id,ad.id);
  if(recent) return res.status(429).json({error:'Please wait before watching the same ad again.'});
  const reward=Number(ad.reward_usd || setting('reward_per_ad_usd'));
  const tx=db.transaction(()=>{
    db.prepare('INSERT INTO watch_events(user_id,ad_id,reward_usd) VALUES(?,?,?)').run(req.user.id,ad.id,reward);
    db.prepare('UPDATE users SET balance_usd=balance_usd+?, lifetime_earned_usd=lifetime_earned_usd+?, ads_watched=ads_watched+1 WHERE id=?').run(reward,reward,req.user.id);
    const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    if(u.referred_by && !u.referral_qualified && u.ads_watched >= Number(setting('referral_ads_required'))) {
      db.prepare('UPDATE users SET balance_usd=balance_usd+?, lifetime_earned_usd=lifetime_earned_usd+? WHERE id=?').run(Number(setting('referral_reward_usd')),Number(setting('referral_reward_usd')),u.referred_by);
      db.prepare('UPDATE users SET referral_qualified=1 WHERE id=?').run(u.id);
    }
  });
  tx(); res.json({ok:true,reward,balance:db.prepare('SELECT balance_usd,ads_watched FROM users WHERE id=?').get(req.user.id)});
});
app.post('/api/ads/:id/click', requireUser, (req,res)=>{db.prepare('UPDATE ads SET clicks=clicks+1 WHERE id=?').run(req.params.id);res.json({ok:true});});
app.post('/api/payouts', requireUser, (req,res)=>{
  const {method,destination}=req.body; const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id); const min=Number(setting('payout_min_usd'));
  if(u.balance_usd < min) return res.status(400).json({error:`Minimum payout is $${min.toFixed(2)}.`});
  if(!['upi','paypal','crypto'].includes(method) || !destination) return res.status(400).json({error:'Choose a payout method and destination.'});
  const amount=Number(u.balance_usd.toFixed(2));
  db.transaction(()=>{db.prepare('INSERT INTO payouts(user_id,amount_usd,method,destination) VALUES(?,?,?,?)').run(u.id,amount,method,destination);db.prepare('UPDATE users SET balance_usd=0 WHERE id=?').run(u.id);})();
  res.json({ok:true});
});

// OAuth endpoints are intentionally scaffolds: add provider SDKs/client credentials before production use.
app.get('/auth/google',(req,res)=>res.status(501).send('Google OAuth is scaffolded. Configure GOOGLE_CLIENT_ID/SECRET and provider callback logic.'));
app.get('/auth/apple',(req,res)=>res.status(501).send('Apple OAuth is scaffolded. Configure Apple Sign In credentials and callback logic.'));

app.post('/api/admin/login',(req,res)=>{
  const {loginId,password}=req.body; const a=db.prepare('SELECT * FROM admin_users WHERE login_id=?').get(loginId);
  if(!a || !verifyPassword(password,a.password_hash)) return res.status(401).json({error:'Invalid admin credentials'});
  const token=makeToken(); adminSessions.set(token,true); res.cookie('admin_session',token,{signed:true,httpOnly:true,sameSite:'strict',secure:process.env.NODE_ENV==='production',maxAge:8*3600*1000}); res.json({ok:true});
});
app.post('/api/admin/logout',(req,res)=>{const t=req.signedCookies.admin_session;if(t)adminSessions.delete(t);res.clearCookie('admin_session');res.json({ok:true});});
app.get('/api/admin/dashboard', requireAdmin,(req,res)=>{
  const users=db.prepare('SELECT id,display_name,email,provider,ads_watched,balance_usd,lifetime_earned_usd,referral_code,created_at,last_seen_at FROM users ORDER BY id DESC').all();
  const payouts=db.prepare('SELECT p.*,u.display_name,u.email FROM payouts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC').all();
  const ads=db.prepare('SELECT * FROM ads ORDER BY id DESC').all();
  const stats=db.prepare('SELECT COUNT(*) users, COALESCE(SUM(lifetime_earned_usd),0) earned, COALESCE(SUM(balance_usd),0) outstanding, COALESCE(SUM(ads_watched),0) watches FROM users').get();
  res.json({users,payouts,ads,stats,settings:Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]))});
});
app.post('/api/admin/ads', requireAdmin,(req,res)=>{const {title,url,embedCode,rewardUsd=Number(setting('reward_per_ad_usd'))}=req.body;if(!title||!url)return res.status(400).json({error:'Title and URL are required'});const r=db.prepare('INSERT INTO ads(title,url,embed_code,reward_usd) VALUES(?,?,?,?)').run(title,url,sanitizeEmbed(embedCode),Number(rewardUsd));res.json({id:r.lastInsertRowid});});
app.patch('/api/admin/ads/:id', requireAdmin,(req,res)=>{const {active,title,url,embedCode,rewardUsd}=req.body;db.prepare('UPDATE ads SET active=COALESCE(?,active),title=COALESCE(?,title),url=COALESCE(?,url),embed_code=COALESCE(?,embed_code),reward_usd=COALESCE(?,reward_usd) WHERE id=?').run(active,title,url,embedCode==null?null:sanitizeEmbed(embedCode),rewardUsd,req.params.id);res.json({ok:true});});
app.post('/api/admin/settings', requireAdmin,(req,res)=>{const allowed=Object.keys(defaults);const tx=db.transaction(()=>{for(const k of allowed)if(req.body[k]!==undefined)db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k,String(req.body[k]));});tx();res.json({ok:true});});
app.patch('/api/admin/payouts/:id', requireAdmin,(req,res)=>{const {status,note}=req.body;if(!['pending','approved','paid','rejected'].includes(status))return res.status(400).json({error:'Invalid status'});db.prepare('UPDATE payouts SET status=?,note=?,processed_at=CASE WHEN ? IN (\'paid\',\'rejected\') THEN CURRENT_TIMESTAMP ELSE processed_at END WHERE id=?').run(status,note||null,status,req.params.id);res.json({ok:true});});

app.get('/admin',(req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('/watch',(req,res)=>res.sendFile(path.join(__dirname,'public','watch.html')));
app.get('/earn',(req,res)=>res.sendFile(path.join(__dirname,'public','earn.html')));
app.get('/account',(req,res)=>res.sendFile(path.join(__dirname,'public','account.html')));
app.get('*',(req,res)=>{ if(req.path.startsWith('/api/')) return res.status(404).end(); res.sendFile(path.join(__dirname,'public','watch.html')); });
if (require.main === module) app.listen(PORT,()=>console.log(`AdWatcher running on http://localhost:${PORT}`));
module.exports = app;
