// Vercel serverless entry point.
// The Express app serves both the UI and API routes.
module.exports = require('../server');
