# Deploy AdWatcher

## Vercel (recommended for this starter)

1. Push this folder to GitHub.
2. Import the repository in Vercel.
3. Add environment variables:
   - `SESSION_SECRET` — long random secret
   - `BASE_URL` — your Vercel/custom-domain URL
   - `ADMIN_ID` — change from the bootstrap value before production
   - `NODE_ENV=production`
4. Deploy. The included `vercel.json` routes the Express app through the Vercel Node function.

### Important persistence note
The starter currently uses SQLite. Vercel serverless storage is not a durable database. For real users, balances, payouts and ad events, replace SQLite with a hosted database such as Postgres/Turso/Supabase/Neon and move sessions to a durable store.

## Netlify

1. Push this folder to GitHub.
2. Import it in Netlify.
3. Build command: `npm run netlify-build`
4. Publish directory: `public`
5. Add `SESSION_SECRET`, `BASE_URL`, `ADMIN_ID`, and `NODE_ENV=production`.
6. The included `netlify.toml` and `netlify/functions/api.js` wire API requests to the Express app.

## Production checklist

- Configure Google OAuth and Apple Sign In with real credentials.
- Use a durable database; do not rely on SQLite in serverless production.
- Use a durable session store.
- Integrate official PayPal/UPI/crypto payment APIs; admin `paid` is currently a bookkeeping status only.
- Add advertiser verification, bot/fraud detection, privacy/consent controls and required legal compliance.
- Do not paste arbitrary JavaScript into ads. The server sanitizes embed HTML.
- Change the supplied bootstrap admin credential before production.
- Use HTTPS and a strong secret manager.
